To install dongle drivers
=========================
1. Log-on as 'root' user
2. run: sh inst

To uninstall dongle drivers
===========================
1. Log-on as 'root' user
2. run: sh uninst