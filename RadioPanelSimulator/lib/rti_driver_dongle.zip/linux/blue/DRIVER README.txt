Dinkey Dongle Drivers for all Linux Kernels
===========================================

Requirements
============
1. usb subsystem (so that usb ports work correctly)
2. the libusb package needs to be installed
   e.g. under Redhat: rpm -Uhv <full name of libusb library>
   e.g. under Debian: apt-get install libusb-0.1-4 (unless there is a later version available)
 The minimum version of libusb required is 0.1.8. Unless your version of Linux
 is very old is will already satisy this. Apart from your Linux provider the
 libusb libaries can also be download from http://libusb.sourceforge.net


To install dongle drivers
=========================
1. Log-on as 'root' user
2. run: sh inst

To uninstall dongle drivers
===========================
1. Log-on as 'root' user
2. run: sh uninst
